<?php

$meminstance = new Memcached();

$meminstance->addServer("127.0.0.1",11211);

$meminstance->set("username","Orka");
$meminstance->set("password","OrkAiSC00L24/7$");
$meminstance->set("salary","$100,000");
$meminstance->set("email","Orka@wekor.thm");
$meminstance->set("id","3476");
