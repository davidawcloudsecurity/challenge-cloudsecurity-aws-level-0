<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root123@#59' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'V_hD%g&hh2BANp3+5fMB?>4lG}<OH*cd(6UnE/WqmdZTLo#8h4tN}[Ckdq`]{@kI' );
define( 'SECURE_AUTH_KEY',  '2^T<ziG&eEjuEzh^-Dk7n57IURC+JY2:(^o(;t<MmSWB-}vc2d6E@%BD9XQ*4}r?' );
define( 'LOGGED_IN_KEY',    '?X`:4j2fx]pZ%a0IGMLzg/nrI/dkz{D%n/nK$2h<%[6VV~TR8XD7-{Xz)hR6V45t' );
define( 'NONCE_KEY',        'Ilx%BU@7^aUY_~S~/?I$09?&bhH.!0U$7dNEr>dAj!;%[$MV<pie0^j,$C1U*tmY' );
define( 'AUTH_SALT',        '&6xsxo(_`wq`-BuAEC[&eN*Z(ecu[.$8dA$HQFV8*SC} ;|DW&?@B@~RhJD7[q(4' );
define( 'SECURE_AUTH_SALT', '/<I;TDbv_G5w,k9MuJ3ESAA=1N$25p*H;)!r-|7T{+rS@%QIF1>l Me::g2Cf2]+' );
define( 'LOGGED_IN_SALT',   'btBt`YR/?0(x)C0/aioT9]7.G{y~eo7C8?P6>@[wfFyygHQ!zkc_kqa`6RY]dE>z' );
define( 'NONCE_SALT',       'gK~TMo/<3*8X0N7G}D{2$&A$5E1^Hv$}`U<=lLa`{<50n1BgRUuE:7;a5h29mH[V' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
