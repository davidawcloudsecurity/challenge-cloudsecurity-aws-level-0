<?php

define("DB_SERVER","localhost");

define("DB_USERNAME" , "root");

define("DB_PASSWORD", "root123@#59");

define("DB_DATABASE", "coupons");

$db = new mysqli(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
$db->set_charset("utf8");

?>
